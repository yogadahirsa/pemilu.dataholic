import { logOut } from '../../services/auth.js';
// import { parseRequestUrl } from '../../services/utils.js';

const Header = {
  /**
   * Render the component content.
   */
  render: async () => {
    
    return /*html*/ `
      <!-- START header-nav -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
<div class="container-fluid">
  <a class="navbar-brand text-primary" href=""><b class="fs-3 ms-1">DATAHOLIC</b><span class="fs-3 text-warning fw-bolder">PEMILU</span></a>
  
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 

  

  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav fs-7">
      <ul class="nav nav-pills nav-fill align-middle flex-column flex-sm-row" id="pills-tab" role="tablist">
        <li class="nav-item">
          <button class="nav-link ps-2 text-start active" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map" type="button" role="tab" aria-controls="pills-map" aria-selected="true"><i class="fa-regular fa-map fa-fw"></i> Sub District Map</button>
        </li>
        <li class="nav-item">
          <button class="nav-link ps-2 text-start" id="pills-heatmap-tab" data-bs-toggle="pill" data-bs-target="#pills-heatmap" type="button" role="tab" aria-controls="pills-heatmap" aria-selected="false"><i class="fa-solid fa-teeth fa-fw"></i> Heatmap</button>
        </li>
        <li class="nav-item">
          <button class="nav-link ps-2 text-start" id="pills-caleg-tab" data-bs-toggle="pill" data-bs-target="#pills-caleg" type="button" role="tab" aria-controls="pills-caleg" aria-selected="false"><i class="fa-solid fa-users fa-fw"></i> Caleg Report</button>
        </li>
        <li class="nav-item">
          <button class="nav-link ps-2 text-start" id="pills-bubble-tab" data-bs-toggle="pill" data-bs-target="#pills-bubble" type="button" role="tab" aria-controls="pills-bubble" aria-selected="false"><i class="fa-brands fa-cloudsmith fa-fw"></i> Bubble War</button>
        </li>
        <li class="nav-item">
          <button class="nav-link ps-2 text-start" id="pills-compete-tab" data-bs-toggle="pill" data-bs-target="#pills-compete" type="button" role="tab" aria-controls="pills-compete" aria-selected="false"><i class="fa-solid fa-network-wired fa-fw"></i> Internal Compete</button>
        </li>
      </ul>
      
    </div>
   
  </div>
  
</div>
<div class="collapse navbar-collapse float-end " id="navbarNavAltMarkup">
<div class='navbar-nav'>
  <p class='nav-item text-danger fw-bold text-start m-2 mx-3 ps-1 float-end logout-button'><i class="fa-solid fa-arrow-right-from-bracket fa-fw"></i><span class='d-md-none'> Logout</span></p>
  </div>
</div>
</nav> 

      <!-- END header-nav -->
         
    `;
  },
  after_render: async () => {
    const elLogout = D.querySelector('.logout-button');
    elLogout.addEventListener("click", function (event) {
      // event.preventDefault();
      logOut();
    });
    // var menus = document.getElementsByClassName("nav-link");

    // for (var i = 0; i < menus.length; i++) {
    //   menus[i].classList.remove("active");
    //   if(menus[i].href.split('#/')[1] == slug.split("/")[1]) {
    //     menus[i].classList.add('text-dark');
    //     menus[i].classList.add('active');
    //     menus[i].classList.add('fw-bold');
    //   } 
    // }

    // flex-column flex-sm-row
  }
};

export default Header;