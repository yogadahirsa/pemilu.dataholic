import { validateonSubmit } from '../../services/auth.js';

const Login = {

    render: async () => {
        return /*html*/ `
        <div class="d-flex align-items-center justify-content-center vh-100">
                        
            <form action="#/" class="form-signin text-center">
                <p class="h2 pb-3 text-success">DATAHOLIC<span class="text-warning fw-bold">PEMILU<span class="text-primary fw-normal">&trade;</span></span></p>
                <div class="alert alert-danger d-none" role="alert">
                    Kombinasi Username dan Password tidak ditemukan
                </div>
                <div class="form-floating">
                <input type="text" class="form-control form-control-sm" id="username">
                <label for="username">Username</label>
                <span class="error-message ps-2 text-danger text-left" style="text-align:left !important"></span>
                </div>
                <div class="form-floating">
                <input type="password" class="form-control form-control-sm" id="password">
                <label for="password">Password</label>
                <span class="error-message ps-2 text-danger text-left" style="text-align:left !important"></span>
                </div>

                <button id="login-button" class="w-100 btn btn-lg btn-primary mt-3" type="submit">Login</button>
                <p class="mt-2 mb-0 text-muted"><small>2023 &copy; DATAHOLIC</small></p>
            </form>
            
        </div>
    `;
    },
    after_render: async () => {
        
        const form = document.querySelector(".form-signin");
            if (form) {
                const fields = ["username", "password"];
                const validator = validateonSubmit(form, fields);
            } 
    
        
    }
};
export default Login;
