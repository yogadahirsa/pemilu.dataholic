import Header from '../components/Header.js';
import {
  TableauViz
} from 'https://public.tableau.com/javascripts/api/tableau.embedding.3.latest.min.js';

const Home = {
  render: async () => {
    const header = await Header.render();
    return /*html*/ `
      ${header}
      <div class="flex-grow-1 p-3 overflow-hidden" data-height="100%">
        <div class="tab-content" id="pills-tabContent">
          <div class="tab-pane fade show active" id="pills-map" role="tabpanel" aria-labelledby="pills-map-tab" tabindex="0">
            <div id="mapViz"></div>
          </div>
          <div class="tab-pane fade" id="pills-heatmap" role="tabpanel" aria-labelledby="pills-heatmap-tab" tabindex="0">
            <div id="heatmapViz"></div>
          </div>
          <div class="tab-pane fade" id="pills-caleg" role="tabpanel" aria-labelledby="pills-caleg-tab" tabindex="0">
            <div id="calegViz"></div>
          </div>
          <div class="tab-pane fade" id="pills-bubble" role="tabpanel" aria-labelledby="pills-bubble-tab" tabindex="0">
            <div id="bubbleViz"></div>
          </div>
          <div class="tab-pane fade" id="pills-compete" role="tabpanel" aria-labelledby="pills-compete-tab" tabindex="0">
            <div id="competeViz"></div>
          </div>
        </div>
      </div>
    `;
  },
  after_render: async () => {
    await Header.after_render();
    const tableauViz = [
      {slug:'map', src:'https://public.tableau.com/shared/HQ93Y6ZKS'},
      {slug:'heatmap', src:'https://public.tableau.com/shared/Z4Q5H98R8'},
      {slug:'caleg', src:'https://public.tableau.com/shared/9XXR6NHPZ'},
      {slug:'bubble', src:'https://public.tableau.com/views/BubblesWar/BubblesWarKecamatan'},
      {slug:'compete', src:'https://public.tableau.com/views/InternalCompete/Dashboard4'}
    ];
    const vizOptions = {
      toolbar:'hidden',
      height:'90vh',
      width:'100vw'
    };
    var loadTableauViz;
    loadViz(loadTableauViz, tableauViz[0].slug+'Viz', tableauViz[0].src);

    tableauViz.forEach(function(v, i) {
      document.getElementById('pills-'+v.slug+'-tab').onclick = function(event) {
        loadViz(loadTableauViz, v.slug+'Viz', v.src)
      }
    });
    
    function loadViz(viz, vizDiv, vizSrc){
      viz = new TableauViz();
      viz.src = vizSrc;
      viz.toolbar = vizOptions.toolbar;
      viz.height = vizOptions.height;
      viz.width = vizOptions.width;
      if(document.getElementById(vizDiv).innerHTML === ''){
        document.getElementById(vizDiv).appendChild(viz);
      }
    }
  }
};
export default Home;
