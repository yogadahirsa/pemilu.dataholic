import { config, setWithExpiry, getWithExpiry, parseRequestUrl } from './services/utils.js';
import { validateAuth } from './services/auth.js';
// import Header from './views/components/Header.js';
import Home from './views/pages/Home.js';
import Login from './views/pages/Login.js';
import Error404 from './views/pages/Error404.js';

window.parseRequestUrl = parseRequestUrl;
window.setWithExpiry = setWithExpiry;
window.getWithExpiry = getWithExpiry;
window.D = document;
window.slug = '';
window.state = {
auth : 1,
token : 'ABCDEFH123456',
api_url : config.api_url,
fetchHeaders : config.fetchHeaders
}

const routes = {
  '/login': Login,
  '/': Home
};

const router = async () => {
  
  const { resource, id, verb } = parseRequestUrl();
  const oauth = !(validateAuth(resource)) ?
  window.location.replace("#/login") :
  (resource === 'login') ? 
    window.location.replace("#/") : null;
  
    const parsedUrl =
      (resource ? '/' + resource : '/') +
      (id ? '/:id' : '') +
      (verb ? '/' + verb : '');

    slug = parsedUrl;
    // parsedUrl === '/' ? window.location.replace("#/calon-legislatif") : null;

    // const header = null || D.getElementById('header');
    const content = null || D.getElementById('content');
    const appClass = D.getElementById("app");
    const page = routes[parsedUrl] || Error404;
    
    // header.innerHTML = await Header.render();
    content.innerHTML = await page.render();
    // await Header.after_render();
    await page.after_render();

};

window.addEventListener('hashchange', router);
window.addEventListener('load', router);
