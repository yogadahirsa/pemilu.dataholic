import { parseRequestUrl } from './services/utils.js';
import Header from './views/components/Header.js';
import CalonLegislatif from './views/pages/CalonLegislatif.js';
import Partai from './views/pages/Partai.js';
import Sebaran from './views/pages/Sebaran.js';
import Error404 from './views/pages/Error404.js';

window.parseRequestUrl = parseRequestUrl;
window.D = document;
window.slug = '';
const routes = {
  '/calon-legislatif': CalonLegislatif,
  '/partai': Partai,
  '/sebaran-suara': Sebaran,
};

const router = async () => {
  
  const { resource, id, verb } = parseRequestUrl();
  
    const parsedUrl =
      (resource ? '/' + resource : '/') +
      (id ? '/:id' : '') +
      (verb ? '/' + verb : '');
    slug = parsedUrl;
    parsedUrl === '/' ? window.location.replace("#/calon-legislatif") : null;

    const header = null || D.getElementById('header');
    const content = null || D.getElementById('content');
    // const appClass = D.getElementById("app");
    const page = routes[parsedUrl] || Error404;
    
    header.innerHTML = await Header.render();
    content.innerHTML = await page.render();
    await Header.after_render();
    await page.after_render();

};

window.addEventListener('hashchange', router);
window.addEventListener('load', router);
