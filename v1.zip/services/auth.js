export const validateAuth = (resource) => {
    const oauth = getWithExpiry("userLogIn");
    if (oauth == null) {
        return false;
    }
    else {
        return true;
    }
}

export const logOut = () => {
    localStorage.removeItem("auth");
    localStorage.removeItem("userProfile");
    localStorage.removeItem("userLogIn");
    window.location.replace("#/login");
}

export const validateonSubmit = (form, fields) => {
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        var error = 0;
        fields.forEach((field) => {
            const input = document.querySelector(`#${field}`);
            if (validateFields(input) == false) {
                error++;
            }
        });
        if (error == 0) {
            var data = {
                username: document.querySelector("#username").value,
                password: document.querySelector("#password").value
            };

            fetch(state.api_url + '/token/index.php', {
                method: 'POST',
                body: JSON.stringify(data),
                headers: state.fetchHeaders,
            })
                .then(function (response) { return response.json(); })
                .then(function (json) {
                    console.log('json',json);
                    if (json.token) {

                        setWithExpiry("auth", 1, 10000 * 60 * 60);
                        setWithExpiry("userLogIn", json.token, 10000 * 60 * 60);
                        setWithExpiry("userProfile", json.username, 10000 * 60 * 60);

                        window.location.reload();

                    } else {
                        console.log("Login failed");
                        document.querySelector('.alert').classList.remove('d-none');
                    }
                })
                .catch(function (err) {
                    return false;
                    console.log(err);
                });
        }
    });
}

const validateFields = (field) => {
    if (field.value.trim() === "") {
        setStatus(
            field,
            `${field.nextElementSibling.innerText} tidak boleh kosong!`,
            "error"
        );
        return false;
    } else {

        setStatus(field, null, "success");
        return true;

    }
}

const setStatus = (field, message, status) => {
    const errorMessage = field.parentElement.querySelector(".error-message");

    // if success, remove messages and error classes
    if (status == "success") {
        if (errorMessage) {
            errorMessage.innerText = "";
        }
        field.classList.remove("input-error");
    }
    // if error, add messages and add error classes
    if (status == "error") {
        errorMessage.innerText = message;
        field.classList.add("input-error");
    }
}